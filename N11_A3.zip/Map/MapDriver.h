//
// Created by fadib on 2021-09-26.
//

#ifndef COMP345_N11_MAPDRIVER_H
#define COMP345_N11_MAPDRIVER_H

#include "../Map/Map.h"
#include "../Player/Player.h"


void mapDriver();


#endif //COMP345_N11_MAPDRIVER_H
