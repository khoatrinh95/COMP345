//
// Created by Khoa Trinh on 2021-11-06.
//

#ifndef COMP345_N11_LOGGINGDRIVER_H
#define COMP345_N11_LOGGINGDRIVER_H
#include "../gameengine/GameEngineDriver.h"
#include "../CommandProcessing/CommandProcessing.h"
void LoggingDriver();


#endif //COMP345_N11_LOGGINGDRIVER_H
